import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { getSampleFeedback, saveFeedback, FeedbackEntry } from "@/lib/mockData";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Navigate } from "react-router-dom";
import { MessageSquare, ThumbsUp, ThumbsDown, Search, Send } from "lucide-react";
import { toast } from "sonner";

const TransactionFeedback = () => {
  const { t } = useLanguage();
  const { isAuthenticated, user } = useAuth();
  const [searchId, setSearchId] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [allFeedback, setAllFeedback] = useState<FeedbackEntry[]>([]);
  const [feedbackType, setFeedbackType] = useState<"good" | "bad">("good");
  const [comment, setComment] = useState("");

  useEffect(() => {
    setAllFeedback(getSampleFeedback());
  }, []);

  if (!isAuthenticated || user?.isAdmin) return <Navigate to="/auth" />;

  const filteredFeedback = activeId
    ? allFeedback.filter((f) => f.transactionId === activeId)
    : [];

  const goodCount = filteredFeedback.filter((f) => f.type === "good").length;
  const badCount = filteredFeedback.filter((f) => f.type === "bad").length;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveId(searchId.trim().toUpperCase());
  };

  const handleSubmitFeedback = () => {
    if (!activeId) return;
    const entry: FeedbackEntry = {
      id: crypto.randomUUID(),
      transactionId: activeId,
      userId: user?.id || "unknown",
      userName: user?.name || "Anonymous",
      type: feedbackType,
      comment,
      date: new Date().toISOString(),
    };
    saveFeedback(entry);
    setAllFeedback((prev) => [entry, ...prev]);
    setComment("");
    toast.success("Feedback submitted!");
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <MessageSquare className="w-8 h-8 text-primary" />
          {t("feedback")}
        </h1>
        <p className="text-muted-foreground mb-8">{t("enterTransactionId")}</p>

        {/* Search */}
        <form onSubmit={handleSearch} className="flex gap-2 mb-8">
          <Input
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            className="bg-secondary border-border"
            placeholder="TXN001000"
          />
          <Button type="submit" className="gradient-primary text-primary-foreground">
            <Search className="w-4 h-4 mr-2" /> {t("viewFeedback")}
          </Button>
        </form>

        {activeId && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
            {/* Summary */}
            <div className="glass-card rounded-xl p-5 mb-6">
              <h2 className="text-lg font-semibold mb-3">{t("transactionId")}: {activeId}</h2>
              <div className="flex gap-4">
                <div className="flex items-center gap-2">
                  <ThumbsUp className="w-5 h-5 text-accent" />
                  <span className="font-semibold">{goodCount}</span>
                  <span className="text-muted-foreground text-sm">{t("positiveFeedback")}</span>
                </div>
                <div className="flex items-center gap-2">
                  <ThumbsDown className="w-5 h-5 text-destructive" />
                  <span className="font-semibold">{badCount}</span>
                  <span className="text-muted-foreground text-sm">{t("negativeFeedback")}</span>
                </div>
              </div>
            </div>

            {/* Submit feedback */}
            <div className="glass-card rounded-xl p-5 mb-6">
              <h3 className="font-semibold mb-3">{t("submitFeedback")}</h3>
              <div className="flex gap-3 mb-3">
                <Button
                  variant={feedbackType === "good" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFeedbackType("good")}
                  className={feedbackType === "good" ? "bg-accent text-accent-foreground" : ""}
                >
                  <ThumbsUp className="w-4 h-4 mr-1" /> {t("goodFeedback")}
                </Button>
                <Button
                  variant={feedbackType === "bad" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setFeedbackType("bad")}
                  className={feedbackType === "bad" ? "bg-destructive text-destructive-foreground" : ""}
                >
                  <ThumbsDown className="w-4 h-4 mr-1" /> {t("badFeedback")}
                </Button>
              </div>
              <Textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder={t("feedbackComment")}
                className="bg-secondary border-border mb-3"
              />
              <Button onClick={handleSubmitFeedback} className="gradient-primary text-primary-foreground">
                <Send className="w-4 h-4 mr-2" /> {t("submitFeedback")}
              </Button>
            </div>

            {/* Feedback list */}
            <div className="glass-card rounded-xl p-5">
              <h3 className="font-semibold mb-3">{t("totalFeedback")}: {filteredFeedback.length}</h3>
              {filteredFeedback.length === 0 ? (
                <p className="text-muted-foreground text-sm py-4 text-center">{t("noFeedbackYet")}</p>
              ) : (
                <div className="space-y-3">
                  {filteredFeedback.map((f) => (
                    <div key={f.id} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50">
                      {f.type === "good" ? (
                        <ThumbsUp className="w-4 h-4 text-accent mt-1 shrink-0" />
                      ) : (
                        <ThumbsDown className="w-4 h-4 text-destructive mt-1 shrink-0" />
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium">{f.userName}</span>
                          <Badge variant="outline" className="text-xs">
                            {f.type === "good" ? t("goodFeedback") : t("badFeedback")}
                          </Badge>
                        </div>
                        {f.comment && <p className="text-sm text-muted-foreground">{f.comment}</p>}
                        <p className="text-xs text-muted-foreground mt-1">{new Date(f.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
};

export default TransactionFeedback;
