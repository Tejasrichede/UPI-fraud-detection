import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  isAdmin: boolean;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string) => boolean;
  adminLogin: (email: string, password: string) => boolean;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const stored = localStorage.getItem("upi_shield_user");
    if (stored) setUser(JSON.parse(stored));
  }, []);

  const persistUser = (u: User) => {
    setUser(u);
    localStorage.setItem("upi_shield_user", JSON.stringify(u));
  };

  const signup = (name: string, email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem("upi_shield_users") || "[]");
    if (users.find((u: any) => u.email === email)) return false;
    const newUser = { id: crypto.randomUUID(), name, email, password, createdAt: new Date().toISOString() };
    users.push(newUser);
    localStorage.setItem("upi_shield_users", JSON.stringify(users));
    persistUser({ id: newUser.id, name, email, isAdmin: false, createdAt: newUser.createdAt });
    return true;
  };

  const login = (email: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem("upi_shield_users") || "[]");
    const found = users.find((u: any) => u.email === email && u.password === password);
    if (!found) return false;
    persistUser({ id: found.id, name: found.name, email: found.email, isAdmin: false, createdAt: found.createdAt });
    return true;
  };

  const adminLogin = (email: string, password: string): boolean => {
    // Demo admin credentials - in production, use server-side auth with Cloud
    if (email === "admin@upishield.com" && password === "Admin@123") {
      persistUser({ id: "admin-001", name: "Administrator", email, isAdmin: true, createdAt: new Date().toISOString() });
      return true;
    }
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("upi_shield_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, adminLogin, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};
