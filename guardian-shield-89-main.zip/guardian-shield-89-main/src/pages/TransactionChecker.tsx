import { useState } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { detectFraud, TransactionInput, FraudResult } from "@/lib/fraudDetection";
import { saveTransaction } from "@/lib/mockData";
import FraudResultCard from "@/components/FraudResultCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Navigate } from "react-router-dom";
import { Search } from "lucide-react";
import { toast } from "sonner";

const channels = [
  { value: "app", label: "Mobile App" },
  { value: "merchant", label: "Merchant" },
  { value: "qr", label: "QR Code" },
  { value: "deeplink", label: "Deeplink" },
  { value: "web", label: "Web" },
];

const TransactionChecker = () => {
  const { t } = useLanguage();
  const { isAuthenticated, user } = useAuth();
  const [result, setResult] = useState<FraudResult | null>(null);
  const [loading, setLoading] = useState(false);

  const [form, setForm] = useState<TransactionInput>({
    userId: "",
    amount: 0,
    timeTaken: 0,
    status: "success",
    failedAttempts: 0,
    pastTransactions: 0,
    channel: "app",
  });

  if (!isAuthenticated || user?.isAdmin) return <Navigate to="/auth" />;

  const update = (key: keyof TransactionInput, value: any) => setForm((p) => ({ ...p, [key]: value }));

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.userId.trim()) { toast.error("User ID is required"); return; }
    setLoading(true);
    setResult(null);

    setTimeout(() => {
      const res = detectFraud(form);
      setResult(res);
      setLoading(false);

      // Save transaction
      saveTransaction({
        id: `TXN${Date.now().toString().slice(-8)}`,
        ...form,
        isFraud: res.isFraud,
        probability: res.probability,
        date: new Date().toISOString(),
      });

      if (res.isFraud) {
        toast.warning("⚠️ This transaction has been flagged as potentially fraudulent!");
      } else {
        toast.success("✅ This transaction appears to be genuine.");
      }
    }, 1500);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Search className="w-8 h-8 text-primary" />
          {t("checkTransaction")}
        </h1>
        <p className="text-muted-foreground mb-8">Enter transaction details to analyze for fraud</p>

        <form onSubmit={handleAnalyze} className="glass-card rounded-xl p-6 space-y-4 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>{t("userId")}</Label>
              <Input value={form.userId} onChange={(e) => update("userId", e.target.value)} className="bg-secondary border-border mt-1" placeholder="USR00123" required />
            </div>
            <div>
              <Label>{t("amount")}</Label>
              <Input type="number" value={form.amount || ""} onChange={(e) => update("amount", Number(e.target.value))} className="bg-secondary border-border mt-1" placeholder="5000" required />
            </div>
            <div>
              <Label>{t("timeTaken")}</Label>
              <Input type="number" step="0.1" value={form.timeTaken || ""} onChange={(e) => update("timeTaken", Number(e.target.value))} className="bg-secondary border-border mt-1" placeholder="15" required />
            </div>
            <div>
              <Label>{t("status")}</Label>
              <Select value={form.status} onValueChange={(v) => update("status", v)}>
                <SelectTrigger className="bg-secondary border-border mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="success">{t("success")}</SelectItem>
                  <SelectItem value="failure">{t("failure")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t("failedAttempts")}</Label>
              <Input type="number" value={form.failedAttempts || ""} onChange={(e) => update("failedAttempts", Number(e.target.value))} className="bg-secondary border-border mt-1" placeholder="0" />
            </div>
            <div>
              <Label>{t("pastTransactions")}</Label>
              <Input type="number" value={form.pastTransactions || ""} onChange={(e) => update("pastTransactions", Number(e.target.value))} className="bg-secondary border-border mt-1" placeholder="50" />
            </div>
            <div className="md:col-span-2">
              <Label>{t("channel")}</Label>
              <Select value={form.channel} onValueChange={(v) => update("channel", v)}>
                <SelectTrigger className="bg-secondary border-border mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {channels.map((c) => (
                    <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full gradient-primary text-primary-foreground font-semibold">
            {loading ? "Analyzing..." : t("analyze")}
          </Button>
        </form>

        {loading && (
          <div className="text-center py-8">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-muted-foreground">Analyzing transaction patterns...</p>
          </div>
        )}

        {result && <FraudResultCard result={result} />}
      </motion.div>
    </div>
  );
};

export default TransactionChecker;
