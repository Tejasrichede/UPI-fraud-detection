import { motion } from "framer-motion";
import { ShieldCheck, ShieldAlert, AlertTriangle, TrendingUp } from "lucide-react";
import type { FraudResult } from "@/lib/fraudDetection";
import { useLanguage } from "@/contexts/LanguageContext";

interface Props {
  result: FraudResult;
}

const FraudResultCard = ({ result }: Props) => {
  const { t } = useLanguage();
  const pct = Math.round(result.probability * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5 }}
      className={`rounded-xl p-6 border ${
        result.isFraud
          ? "border-destructive/40 glow-danger bg-destructive/5"
          : "border-accent/40 glow-success bg-accent/5"
      }`}
    >
      <div className="flex items-center gap-4 mb-4">
        <div className={`p-3 rounded-full ${result.isFraud ? "gradient-danger" : "gradient-success"}`}>
          {result.isFraud ? <ShieldAlert className="w-8 h-8 text-foreground" /> : <ShieldCheck className="w-8 h-8 text-primary-foreground" />}
        </div>
        <div>
          <h3 className={`text-2xl font-bold ${result.isFraud ? "text-destructive" : "text-accent"}`}>
            {result.isFraud ? t("fraudulent") : t("genuine")}
          </h3>
          <p className="text-muted-foreground text-sm">{t("probability")}: {pct}%</p>
        </div>
      </div>

      {/* Probability bar */}
      <div className="mb-4">
        <div className="h-3 rounded-full bg-secondary overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${pct}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className={`h-full rounded-full ${result.isFraud ? "gradient-danger" : "gradient-success"}`}
          />
        </div>
      </div>

      {/* Risk factors */}
      {result.riskFactors.length > 0 && (
        <div className="mb-4">
          <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-yellow-500" /> Risk Factors
          </h4>
          <ul className="space-y-1">
            {result.riskFactors.map((f, i) => (
              <li key={i} className="text-sm text-muted-foreground flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                {f}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Model accuracy */}
      <div className="flex items-center gap-2 pt-3 border-t border-border">
        <TrendingUp className="w-4 h-4 text-primary" />
        <span className="text-sm text-muted-foreground">{t("modelAccuracy")}:</span>
        <span className="text-sm font-semibold text-primary">{result.modelAccuracy}%</span>
      </div>
    </motion.div>
  );
};

export default FraudResultCard;
