import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import LanguageSwitcher from "./LanguageSwitcher";
import { Button } from "@/components/ui/button";
import { Shield, LogOut, LayoutDashboard, Search, MessageSquare } from "lucide-react";

const Navbar = () => {
  const { user, logout, isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();

  return (
    <nav className="sticky top-0 z-50 glass-card border-b border-border/50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <Shield className="w-7 h-7 text-primary group-hover:drop-shadow-[0_0_8px_hsl(185_80%_45%/0.5)] transition-all" />
          <span className="text-lg font-bold text-gradient">{t("appName")}</span>
        </Link>

        <div className="flex items-center gap-3">
          {isAuthenticated && !user?.isAdmin && (
            <>
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("dashboard")}</span>
                </Button>
              </Link>
              <Link to="/check">
                <Button variant="ghost" size="sm" className="gap-2">
                  <Search className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("checkTransaction")}</span>
                </Button>
              </Link>
              <Link to="/feedback">
                <Button variant="ghost" size="sm" className="gap-2">
                  <MessageSquare className="w-4 h-4" />
                  <span className="hidden sm:inline">{t("feedback")}</span>
                </Button>
              </Link>
            </>
          )}
          {user?.isAdmin && (
            <Link to="/admin">
              <Button variant="ghost" size="sm" className="gap-2">
                <LayoutDashboard className="w-4 h-4" />
                {t("adminPanel")}
              </Button>
            </Link>
          )}
          <LanguageSwitcher />
          {isAuthenticated ? (
            <Button variant="outline" size="sm" onClick={() => { logout(); navigate("/"); }} className="gap-2">
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">{t("logout")}</span>
            </Button>
          ) : (
            <Link to="/auth">
              <Button size="sm" className="gradient-primary text-primary-foreground font-semibold">
                {t("login")}
              </Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
