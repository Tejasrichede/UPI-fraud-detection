import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { getInitialTransactions, getSampleFeedback, Transaction, FeedbackEntry } from "@/lib/mockData";
import { Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LayoutDashboard, FileText, MessageSquare, ShieldAlert,
  ShieldCheck, Activity, Download, ThumbsUp, ThumbsDown, Users, Search
} from "lucide-react";
import jsPDF from "jspdf";

const AdminDashboard = () => {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [feedback, setFeedback] = useState<FeedbackEntry[]>([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    setTransactions(getInitialTransactions());
    setFeedback(getSampleFeedback());
  }, []);

  if (!isAuthenticated || !user?.isAdmin) return <Navigate to="/admin-portal" />;

  const fraudCount = transactions.filter((tx) => tx.isFraud).length;
  const filtered = transactions.filter(
    (tx) => tx.id.toLowerCase().includes(search.toLowerCase()) || tx.userId.toLowerCase().includes(search.toLowerCase())
  );

  // Flagged accounts: users with multiple fraud transactions
  const accountFlags: Record<string, number> = {};
  transactions.filter((tx) => tx.isFraud).forEach((tx) => {
    accountFlags[tx.userId] = (accountFlags[tx.userId] || 0) + 1;
  });
  const flaggedAccounts = Object.entries(accountFlags)
    .sort((a, b) => b[1] - a[1])
    .map(([userId, count]) => ({ userId, count }));

  // Feedback per transaction
  const feedbackByTxn: Record<string, { good: number; bad: number; entries: FeedbackEntry[] }> = {};
  feedback.forEach((f) => {
    if (!feedbackByTxn[f.transactionId]) feedbackByTxn[f.transactionId] = { good: 0, bad: 0, entries: [] };
    feedbackByTxn[f.transactionId][f.type === "good" ? "good" : "bad"]++;
    feedbackByTxn[f.transactionId].entries.push(f);
  });

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text("UPI Shield - Fraud Analysis Report", 14, 22);
    doc.setFontSize(10);
    doc.text(`Generated: ${new Date().toLocaleString()}`, 14, 30);
    doc.text(`Total Transactions: ${transactions.length}`, 14, 38);
    doc.text(`Fraudulent: ${fraudCount}`, 14, 44);
    doc.text(`Genuine: ${transactions.length - fraudCount}`, 14, 50);

    doc.setFontSize(12);
    doc.text("Recent Transactions:", 14, 62);
    doc.setFontSize(8);

    let y = 70;
    const headers = ["ID", "User", "Amount", "Channel", "Result", "Score", "Date"];
    headers.forEach((h, i) => doc.text(h, 14 + i * 27, y));
    y += 6;

    transactions.slice(0, 30).forEach((tx) => {
      if (y > 280) { doc.addPage(); y = 20; }
      const row = [tx.id, tx.userId, `₹${tx.amount}`, tx.channel, tx.isFraud ? "FRAUD" : "OK", `${Math.round(tx.probability * 100)}%`, new Date(tx.date).toLocaleDateString()];
      row.forEach((val, i) => doc.text(val, 14 + i * 27, y));
      y += 5;
    });

    doc.save("UPI_Shield_Report.pdf");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <LayoutDashboard className="w-8 h-8 text-primary" />
              {t("adminPanel")}
            </h1>
            <p className="text-muted-foreground mt-1">Monitor transactions, feedback, and flagged accounts</p>
          </div>
          <Button onClick={generatePDF} className="gradient-primary text-primary-foreground gap-2">
            <Download className="w-4 h-4" /> {t("generateReport")}
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { icon: Activity, label: t("totalTransactions"), value: transactions.length, color: "text-primary" },
            { icon: ShieldAlert, label: t("flaggedTransactions"), value: fraudCount, color: "text-destructive" },
            { icon: ShieldCheck, label: t("genuineTransactions"), value: transactions.length - fraudCount, color: "text-accent" },
            { icon: MessageSquare, label: t("totalFeedback"), value: feedback.length, color: "text-primary" },
          ].map((s, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }} className="glass-card rounded-xl p-4">
              <div className="flex items-center gap-3">
                <s.icon className={`w-5 h-5 ${s.color}`} />
                <div>
                  <p className="text-xs text-muted-foreground">{s.label}</p>
                  <p className="text-xl font-bold">{s.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="transactions" className="space-y-4">
          <TabsList className="bg-secondary">
            <TabsTrigger value="transactions">{t("allTransactions")}</TabsTrigger>
            <TabsTrigger value="flagged">{t("flaggedAccounts")}</TabsTrigger>
            <TabsTrigger value="feedback">{t("userFeedback")}</TabsTrigger>
          </TabsList>

          <TabsContent value="transactions">
            <div className="glass-card rounded-xl p-5">
              <div className="flex items-center gap-2 mb-4">
                <Search className="w-4 h-4 text-muted-foreground" />
                <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t("searchTransactions")} className="bg-secondary border-border max-w-sm" />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground text-xs">
                      <th className="text-left py-3 px-2">ID</th>
                      <th className="text-left py-3 px-2">{t("userId")}</th>
                      <th className="text-left py-3 px-2">{t("amount")}</th>
                      <th className="text-left py-3 px-2">{t("channel")}</th>
                      <th className="text-left py-3 px-2">{t("status")}</th>
                      <th className="text-left py-3 px-2">{t("result")}</th>
                      <th className="text-left py-3 px-2">{t("score")}</th>
                      <th className="text-left py-3 px-2">{t("date")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((tx) => (
                      <tr key={tx.id} className="border-b border-border/50 hover:bg-secondary/30 text-xs">
                        <td className="py-2 px-2 font-mono">{tx.id}</td>
                        <td className="py-2 px-2">{tx.userId}</td>
                        <td className="py-2 px-2">₹{tx.amount.toLocaleString()}</td>
                        <td className="py-2 px-2 capitalize">{tx.channel}</td>
                        <td className="py-2 px-2">
                          <Badge variant="outline" className="text-xs">{tx.status}</Badge>
                        </td>
                        <td className="py-2 px-2">
                          <Badge variant={tx.isFraud ? "destructive" : "default"} className={tx.isFraud ? "" : "bg-accent text-accent-foreground"}>
                            {tx.isFraud ? "Fraud" : "Genuine"}
                          </Badge>
                        </td>
                        <td className="py-2 px-2">{Math.round(tx.probability * 100)}%</td>
                        <td className="py-2 px-2 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="flagged">
            <div className="glass-card rounded-xl p-5">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Users className="w-5 h-5 text-destructive" />
                Frequently Flagged Accounts
              </h3>
              {flaggedAccounts.length === 0 ? (
                <p className="text-muted-foreground text-sm">No flagged accounts</p>
              ) : (
                <div className="space-y-2">
                  {flaggedAccounts.map((a) => (
                    <div key={a.userId} className="flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/10">
                      <div className="flex items-center gap-3">
                        <ShieldAlert className="w-5 h-5 text-destructive" />
                        <span className="font-mono text-sm">{a.userId}</span>
                      </div>
                      <Badge variant="destructive">{a.count} flagged transaction{a.count > 1 ? "s" : ""}</Badge>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="feedback">
            <div className="glass-card rounded-xl p-5">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                All Feedback by Transaction
              </h3>
              {Object.entries(feedbackByTxn).length === 0 ? (
                <p className="text-muted-foreground text-sm">No feedback yet</p>
              ) : (
                <div className="space-y-4">
                  {Object.entries(feedbackByTxn).map(([txnId, data]) => (
                    <div key={txnId} className="p-4 rounded-lg bg-secondary/50 border border-border/50">
                      <div className="flex items-center justify-between mb-3">
                        <span className="font-mono text-sm font-semibold">{txnId}</span>
                        <div className="flex gap-3">
                          <span className="flex items-center gap-1 text-sm">
                            <ThumbsUp className="w-4 h-4 text-accent" /> {data.good}
                          </span>
                          <span className="flex items-center gap-1 text-sm">
                            <ThumbsDown className="w-4 h-4 text-destructive" /> {data.bad}
                          </span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        {data.entries.slice(0, 3).map((f) => (
                          <div key={f.id} className="text-xs text-muted-foreground flex items-start gap-2">
                            {f.type === "good" ? <ThumbsUp className="w-3 h-3 text-accent mt-0.5 shrink-0" /> : <ThumbsDown className="w-3 h-3 text-destructive mt-0.5 shrink-0" />}
                            <span>{f.userName}: {f.comment}</span>
                          </div>
                        ))}
                        {data.entries.length > 3 && (
                          <p className="text-xs text-muted-foreground">+{data.entries.length - 3} more</p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
};

export default AdminDashboard;
