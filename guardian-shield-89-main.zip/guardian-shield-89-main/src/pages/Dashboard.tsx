import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { getInitialTransactions, Transaction } from "@/lib/mockData";
import { ShieldCheck, ShieldAlert, Activity, AlertTriangle, Clock } from "lucide-react";
import { Navigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

const Dashboard = () => {
  const { t } = useLanguage();
  const { user, isAuthenticated } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  useEffect(() => {
    setTransactions(getInitialTransactions());
  }, []);

  if (!isAuthenticated || user?.isAdmin) return <Navigate to="/auth" />;

  const userTxns = transactions;
  const fraudCount = userTxns.filter((tx) => tx.isFraud).length;
  const genuineCount = userTxns.length - fraudCount;

  const alerts = userTxns
    .filter((tx) => tx.isFraud)
    .slice(0, 5)
    .map((tx) => ({
      id: tx.id,
      message: `Suspicious transaction ${tx.id} - ₹${tx.amount.toLocaleString()}`,
      date: tx.date,
    }));

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h1 className="text-3xl font-bold mb-2">{t("dashboard")}</h1>
        <p className="text-muted-foreground mb-8">Welcome back, {user?.name}</p>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {[
            { icon: Activity, label: t("totalTransactions"), value: userTxns.length, color: "text-primary" },
            { icon: ShieldAlert, label: t("flaggedTransactions"), value: fraudCount, color: "text-destructive" },
            { icon: ShieldCheck, label: t("genuineTransactions"), value: genuineCount, color: "text-accent" },
          ].map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="glass-card rounded-xl p-5"
            >
              <div className="flex items-center gap-3">
                <s.icon className={`w-6 h-6 ${s.color}`} />
                <div>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                  <p className="text-2xl font-bold">{s.value}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Alerts */}
        {alerts.length > 0 && (
          <div className="glass-card rounded-xl p-5 mb-8 border-destructive/20">
            <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              {t("recentAlerts")}
            </h2>
            <div className="space-y-2">
              {alerts.map((a) => (
                <div key={a.id} className="flex items-center justify-between p-3 rounded-lg bg-destructive/5 border border-destructive/10">
                  <span className="text-sm">{a.message}</span>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(a.date).toLocaleDateString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Transaction History */}
        <div className="glass-card rounded-xl p-5">
          <h2 className="text-lg font-semibold mb-4">{t("transactionHistory")}</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-muted-foreground">
                  <th className="text-left py-3 px-2">{t("transactionId")}</th>
                  <th className="text-left py-3 px-2">{t("amount")}</th>
                  <th className="text-left py-3 px-2">{t("channel")}</th>
                  <th className="text-left py-3 px-2">{t("date")}</th>
                  <th className="text-left py-3 px-2">{t("result")}</th>
                  <th className="text-left py-3 px-2">{t("score")}</th>
                </tr>
              </thead>
              <tbody>
                {userTxns.slice(0, 15).map((tx) => (
                  <tr key={tx.id} className="border-b border-border/50 hover:bg-secondary/30">
                    <td className="py-3 px-2 font-mono text-xs">{tx.id}</td>
                    <td className="py-3 px-2">₹{tx.amount.toLocaleString()}</td>
                    <td className="py-3 px-2 capitalize">{tx.channel}</td>
                    <td className="py-3 px-2 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                    <td className="py-3 px-2">
                      <Badge variant={tx.isFraud ? "destructive" : "default"} className={tx.isFraud ? "" : "bg-accent text-accent-foreground"}>
                        {tx.isFraud ? t("fraudulent") : t("genuine")}
                      </Badge>
                    </td>
                    <td className="py-3 px-2">{Math.round(tx.probability * 100)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Dashboard;
