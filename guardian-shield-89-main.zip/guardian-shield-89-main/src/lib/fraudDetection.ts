export interface TransactionInput {
  userId: string;
  amount: number;
  timeTaken: number;
  status: "success" | "failure";
  failedAttempts: number;
  pastTransactions: number;
  channel: string;
}

export interface FraudResult {
  isFraud: boolean;
  probability: number;
  riskFactors: string[];
  modelAccuracy: number;
}

const CHANNEL_RISK: Record<string, number> = {
  app: 0.1,
  merchant: 0.15,
  qr: 0.2,
  deeplink: 0.35,
  web: 0.3,
  other: 0.25,
};

export function detectFraud(input: TransactionInput): FraudResult {
  const riskFactors: string[] = [];
  let score = 0;

  // Amount analysis
  if (input.amount > 50000) { score += 0.25; riskFactors.push("Very high transaction amount"); }
  else if (input.amount > 20000) { score += 0.15; riskFactors.push("High transaction amount"); }
  else if (input.amount > 10000) { score += 0.08; }

  // Time analysis
  if (input.timeTaken < 2) { score += 0.2; riskFactors.push("Unusually fast transaction"); }
  else if (input.timeTaken > 120) { score += 0.15; riskFactors.push("Unusually slow transaction"); }

  // Failed auth
  if (input.failedAttempts >= 5) { score += 0.3; riskFactors.push("Multiple failed authentication attempts"); }
  else if (input.failedAttempts >= 3) { score += 0.2; riskFactors.push("Several failed auth attempts"); }
  else if (input.failedAttempts >= 1) { score += 0.08; }

  // Past transactions (new accounts are riskier)
  if (input.pastTransactions < 3) { score += 0.2; riskFactors.push("New account with few transactions"); }
  else if (input.pastTransactions < 10) { score += 0.1; }
  else { score -= 0.05; }

  // Transaction status
  if (input.status === "failure") { score += 0.15; riskFactors.push("Transaction failed"); }

  // Channel risk
  const channelRisk = CHANNEL_RISK[input.channel] || 0.25;
  score += channelRisk;
  if (channelRisk >= 0.3) riskFactors.push(`High-risk channel: ${input.channel}`);

  // Normalize
  const probability = Math.min(Math.max(score, 0.02), 0.98);
  const isFraud = probability > 0.5;

  // Simulated model accuracy (slightly random to feel realistic)
  const modelAccuracy = 94.2 + (Math.random() * 2 - 1);

  return { isFraud, probability, riskFactors, modelAccuracy: Math.round(modelAccuracy * 10) / 10 };
}
