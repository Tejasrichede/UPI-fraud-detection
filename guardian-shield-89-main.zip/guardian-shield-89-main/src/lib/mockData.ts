export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  timeTaken: number;
  status: "success" | "failure";
  failedAttempts: number;
  pastTransactions: number;
  channel: string;
  isFraud: boolean;
  probability: number;
  date: string;
}

export interface FeedbackEntry {
  id: string;
  transactionId: string;
  userId: string;
  userName: string;
  type: "good" | "bad";
  comment: string;
  date: string;
}

const channels = ["app", "merchant", "qr", "deeplink", "web"];
const names = ["Rahul S.", "Priya M.", "Amit K.", "Sneha R.", "Vikram T.", "Ananya P.", "Rohan D.", "Kavya N."];

function randomDate(daysBack: number): string {
  const d = new Date();
  d.setDate(d.getDate() - Math.floor(Math.random() * daysBack));
  d.setHours(Math.floor(Math.random() * 24), Math.floor(Math.random() * 60));
  return d.toISOString();
}

export function getInitialTransactions(): Transaction[] {
  const stored = localStorage.getItem("upi_shield_transactions");
  if (stored) return JSON.parse(stored);

  const txns: Transaction[] = Array.from({ length: 25 }, (_, i) => {
    const isFraud = Math.random() > 0.75;
    return {
      id: `TXN${String(1000 + i).padStart(6, "0")}`,
      userId: `USR${String(100 + Math.floor(Math.random() * 20)).padStart(5, "0")}`,
      amount: isFraud ? Math.floor(Math.random() * 80000) + 10000 : Math.floor(Math.random() * 15000) + 100,
      timeTaken: isFraud ? Math.random() * 3 + 0.5 : Math.random() * 30 + 5,
      status: (isFraud && Math.random() > 0.5 ? "failure" : "success") as "success" | "failure",
      failedAttempts: isFraud ? Math.floor(Math.random() * 8) + 2 : Math.floor(Math.random() * 2),
      pastTransactions: isFraud ? Math.floor(Math.random() * 5) : Math.floor(Math.random() * 100) + 10,
      channel: channels[Math.floor(Math.random() * channels.length)],
      isFraud,
      probability: isFraud ? 0.6 + Math.random() * 0.35 : 0.05 + Math.random() * 0.35,
      date: randomDate(30),
    };
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  localStorage.setItem("upi_shield_transactions", JSON.stringify(txns));
  return txns;
}

export function saveTransaction(txn: Transaction) {
  const txns = getInitialTransactions();
  txns.unshift(txn);
  localStorage.setItem("upi_shield_transactions", JSON.stringify(txns));
}

export function getFeedback(): FeedbackEntry[] {
  return JSON.parse(localStorage.getItem("upi_shield_feedback") || "[]");
}

export function saveFeedback(entry: FeedbackEntry) {
  const fb = getFeedback();
  fb.unshift(entry);
  localStorage.setItem("upi_shield_feedback", JSON.stringify(fb));
}

export function getSampleFeedback(): FeedbackEntry[] {
  const stored = getFeedback();
  if (stored.length > 0) return stored;

  const txns = getInitialTransactions();
  const samples: FeedbackEntry[] = txns.slice(0, 10).flatMap((txn) => {
    const count = Math.floor(Math.random() * 3) + 1;
    return Array.from({ length: count }, () => ({
      id: crypto.randomUUID(),
      transactionId: txn.id,
      userId: `USR${String(100 + Math.floor(Math.random() * 20)).padStart(5, "0")}`,
      userName: names[Math.floor(Math.random() * names.length)],
      type: (Math.random() > (txn.isFraud ? 0.3 : 0.8) ? "bad" : "good") as "good" | "bad",
      comment: txn.isFraud
        ? ["Suspicious activity", "Didn't authorize this", "Possible fraud"][Math.floor(Math.random() * 3)]
        : ["Legitimate transaction", "All good", "Verified by me"][Math.floor(Math.random() * 3)],
      date: randomDate(15),
    }));
  });

  localStorage.setItem("upi_shield_feedback", JSON.stringify(samples));
  return samples;
}
